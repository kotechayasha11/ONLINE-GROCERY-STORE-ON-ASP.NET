﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class cregister : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");
   
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        cmd = new SqlCommand("insert into users(cnm,password,email,address,c_phn_no)Values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox6.Text + "','" + TextBox5.Text + "','" + TextBox7.Text + "')", con);
        con.Open();


        int res = cmd.ExecuteNonQuery();
        con.Close();
        if (res > 0)
        {
            //Response.Write("<script>alert('Register');</script>");
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox6.Text = "";
            TextBox5.Text = "";
            TextBox7.Text = "";
            Response.Redirect("~/clogin.aspx");
            
        }
        else
        {
            Response.Write("<script>alert('Try Again');</script>");
        }
    }
    
    
}