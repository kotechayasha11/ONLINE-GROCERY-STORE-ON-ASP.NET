﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Admin_user : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "del")
        {
            int cid = Convert.ToInt32(e.CommandArgument);
            SqlConnection con;
            SqlCommand com;
            int r;
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");
            com = con.CreateCommand();
            com.CommandText = "delete from users where cid=@cid";
            com.Parameters.AddWithValue("@cid", cid);
            con.Open();
            r = com.ExecuteNonQuery();
            con.Close();
            GridView1.DataBind();
        }
    }
}