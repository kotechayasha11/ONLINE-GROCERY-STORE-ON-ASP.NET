﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_product : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");
     
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=Fruits");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=Vegetable");
    }
    
    protected void Button4_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
       
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox13.Text = "";

    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=Foodgrain");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        FileUpload1.SaveAs(Server.MapPath("image/") + Path.GetFileName(FileUpload1.FileName));
        String link = "image/" + Path.GetFileName(FileUpload1.FileName);
        cmd = new SqlCommand("insert into product(p_image,p_nm,p_type,p_subtype,p_mesurment,price,stock,offer)Values('" + link + "','" + TextBox1.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox13.Text + "','" + TextBox3.Text + "')", con);
        con.Open();
        int res = cmd.ExecuteNonQuery();
        con.Close();
        if (res > 0)
        {
            Response.Write("<script>alert('Product inserted');</script>");
            TextBox1.Text = "";

            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox13.Text = "";
        }
        else
        {
            Response.Write("<script>alert('not');</script>");
        }
    }
   
    protected void Button15_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=snacks");
    }
    protected void Button16_Click(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=beauty");
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Viewproduct.aspx?p_type=masala");
    }
}