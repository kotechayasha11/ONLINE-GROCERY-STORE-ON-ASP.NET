﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Admin_pupdate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            SqlConnection con;
            SqlCommand com;
            SqlDataReader red;
            int pid = int.Parse(Request.QueryString["pid"]);
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");

           com = con.CreateCommand();
            com.CommandText = "select * from product where pid=@pid";
            com.Parameters.AddWithValue("@pid", pid);
            con.Open();
            red = com.ExecuteReader();
            red.Read();
            TextBox1.Text = red["p_nm"].ToString();
            TextBox2.Text = red["p_type"].ToString();
            TextBox5.Text = red["p_subtype"].ToString();
            TextBox7.Text = red["p_mesurment"].ToString();
            TextBox3.Text = red["price"].ToString();
            TextBox4.Text = red["stock"].ToString();
            TextBox6.Text = red["offer"].ToString();
            red.Close();
            con.Close();
            Label9.Text = pid.ToString();
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        int pid = int.Parse(Label9.Text);
        SqlConnection con;
        SqlCommand com;
        int r = 0;
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");

        com = con.CreateCommand();
        com.CommandText = "update product set p_nm=@p_nm,p_type=@p_type,p_subtype=@p_subtype,p_mesurment=@p_mesurment,price=@price,stock=@stock,offer=@offer where pid=@pid";
        com.Parameters.AddWithValue("@pid", pid);
        com.Parameters.AddWithValue("@p_nm", TextBox1.Text.ToString());
        com.Parameters.AddWithValue("@p_type", TextBox2.Text.ToString());
        com.Parameters.AddWithValue("@p_subtype", TextBox5.Text.ToString());
        com.Parameters.AddWithValue("@p_mesurment", TextBox7.Text.ToString());
        com.Parameters.AddWithValue("@price", TextBox3.Text.ToString());
        com.Parameters.AddWithValue("@stock", TextBox4.Text.ToString());
        com.Parameters.AddWithValue("@offer", TextBox6.Text.ToString());
        con.Open();
        r = com.ExecuteNonQuery();
        con.Close();
        Response.Redirect("product.aspx");

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("product.aspx");
    }
}