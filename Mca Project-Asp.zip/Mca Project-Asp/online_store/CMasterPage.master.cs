﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn1(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Fruits");
    }
    protected void btn2(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Vegatable");
    }
    protected void btn4(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Atta");
    }
    protected void btn5(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=rice");
    }
    protected void btn6(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=dal");
    }
    protected void btn7(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=salt");
    }
    protected void btn8(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=masala");
    }
    protected void btn10(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=choclate");
    }
    protected void btn11(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Noodles");
    }
    protected void btn12(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=biscuit");
    }
    protected void btn13(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=namkeen");
    }
    protected void btn14(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=ketchup");
    }
    protected void btn16(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=soap");
    }
    protected void btn17(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=hair");
    }
    protected void btn18(object sender, EventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=hair");
    }
}
