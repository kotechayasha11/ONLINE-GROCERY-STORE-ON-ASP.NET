﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class viewproduct : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
       
        if (e.CommandName == "addtocart")
        {


            TextBox t1 = (TextBox)e.Item.FindControl("TextBox1");
            Label l1 = (Label)e.Item.FindControl("pidLabel");
            Label l2 = (Label)e.Item.FindControl("Label1");//image
            Label l3 = (Label)e.Item.FindControl("p_nmLabel");
            Label l4 = (Label)e.Item.FindControl("p_typeLabel");
            Label l5 = (Label)e.Item.FindControl("p_subtypeLabel");
            Label l6 = (Label)e.Item.FindControl("p_mesurmentLabel");
            Label l7 = (Label)e.Item.FindControl("priceLabel");
            Label l8 = (Label)e.Item.FindControl("stockLabel");
            Label l9 = (Label)e.Item.FindControl("offerLabel");
            SqlConnection con;
            SqlCommand com;
            //t1.Text = "1";
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");

            com = con.CreateCommand();
            com.CommandText = "insert into cart(p_nm,p_type,p_subtype,p_mesurment,price,stock,offer,qty) values(@p_nm,@p_type,@p_subtype,@p_mesurment,@price,@stock,@offer,@qty)";

 //           com.Parameters.AddWithValue("@pid", l1.Text);
   //         com.Parameters.AddWithValue("@p_image", l2.Text);
            com.Parameters.AddWithValue("@p_nm", l3.Text);
            com.Parameters.AddWithValue("@p_type", l4.Text);
            com.Parameters.AddWithValue("@p_subtype", l5.Text);
            com.Parameters.AddWithValue("@p_mesurment", l6.Text);
            com.Parameters.AddWithValue("@price", l7.Text);
            com.Parameters.AddWithValue("@stock", l8.Text);
            com.Parameters.AddWithValue("@offer", l9.Text);
            com.Parameters.AddWithValue("@qty", t1.Text);
            con.Open();
            int r = com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("~/cart.aspx");
        }

    }
}