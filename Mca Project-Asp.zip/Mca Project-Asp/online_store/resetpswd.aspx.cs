﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class resetpswd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String email = Request.QueryString["uemail"];
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        String email = Request.QueryString["uemail"];
        if (TextBox1.Text == TextBox2.Text)
        {
            
            SqlConnection con;
            SqlCommand com;
            int r = 0;
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");

            com = con.CreateCommand();
            com.CommandText = "update users set password=@password where email=@email";
            com.Parameters.AddWithValue("@email", email);
            com.Parameters.AddWithValue("@password",TextBox1.Text.ToString() );
            
            con.Open();
            r = com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("clogin.aspx");
        }
        else
        {
            Response.Write("<script>alert('Password and Confirm Password does not match");

        }
    }
}