﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class chome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }


    protected void  ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Fruits");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=Vegatable");
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/c_viewproduct.aspx?p_subtype=Atta,&p_subtype=dal,&p_subtype=rice");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=masala ");
    }
   
    
    protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=snacks,&p_subtype=Choclate,&p_subtype=Noodles");
    }
   
    protected void ImageButton8_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("c_viewproduct.aspx?p_subtype=beauty");
    }
    
}
    