﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using  System.Data;
using System.Data.SqlClient;

public partial class cart : System.Web.UI.Page
{
     protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["Name"] != null)
        {
            lblname.Text = Session["Name"].ToString();

        }

        if (Session["Password"] != null)
        {
            lblpsw.Text = Session["Password"].ToString();

            //'<%# ((Convert.ToInt32(Eval("qty")))*((Convert.ToInt32(Eval("price")))))%>'></asp:Label>

        }
        if (Session["Name"] == null)
        {
            Response.Redirect("clogin.aspx");
        }
        if (Session["Password"] == null)
        {
            Response.Redirect("clogin.aspx");


        }





    }
    protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "del")
        {
            int cart_id = Convert.ToInt32(e.CommandArgument);
            SqlConnection con;
            SqlCommand com;
            int r;
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\lenovo\Documents\Visual Studio 2010\WebSites\online_store\App_Data\grocery.mdf;Integrated Security=True;User Instance=True");
            com = con.CreateCommand();
            com.CommandText = "delete from cart where cart_id=@cart_id";
            com.Parameters.AddWithValue("@cart_id", cart_id);
            con.Open();
            r = com.ExecuteNonQuery();
            con.Close();
            GridView1.DataBind();
            
        }
       
    }



    int sum = 0;
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label x = (Label)e.Row.FindControl("lblamt");
            sum = sum + int.Parse(x.Text);
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label x = (Label)e.Row.FindControl("lbltotal");
            x.Text = sum.ToString();
            //sum = sum + int.Parse(x.Text);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        Response.Redirect("payc.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("payc.aspx");
    }
}
   
      
 
    