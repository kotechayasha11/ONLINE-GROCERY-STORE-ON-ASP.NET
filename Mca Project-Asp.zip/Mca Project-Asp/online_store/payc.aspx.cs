﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class payc : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["Name"] != null)
        {
            lblname.Text = Session["Name"].ToString();

        }

        if (Session["Password"] != null)
        {
            lblpsw.Text = Session["Password"].ToString();

            //'<%# ((Convert.ToInt32(Eval("qty")))*((Convert.ToInt32(Eval("price")))))%>'></asp:Label>

        }
        if (Session["Name"] == null)
        {
            //Response.Write("<h1><b>Please Login</b></h1>");
        }
        if (Session["Password"] == null)
        {
           // Response.Write("<h1><b>Please Login</b></h1>");


        }
    }
    int sum = 0;
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label x = (Label)e.Row.FindControl("lblamt");
            sum = sum + int.Parse(x.Text);
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label x = (Label)e.Row.FindControl("lbltotal");
            x.Text = sum.ToString();
            //sum = sum + int.Parse(x.Text);
        }
    }

}